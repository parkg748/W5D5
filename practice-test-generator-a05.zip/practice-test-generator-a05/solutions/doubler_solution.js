function doubler(array) {
  return array.map( el => el * 2 );
}
