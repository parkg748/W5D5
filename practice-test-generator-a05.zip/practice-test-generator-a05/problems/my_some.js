Array.prototype.mySome = function (func) {

}
