Array.prototype.bubbleSort = function (func) {

}
