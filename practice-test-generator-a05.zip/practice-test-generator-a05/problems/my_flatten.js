Array.prototype.flatten = function () {

}
