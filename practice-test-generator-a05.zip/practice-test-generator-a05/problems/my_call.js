Function.prototype.myCall = function (ctx, ...args) {

};
