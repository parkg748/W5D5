// Write a recursive method that returns all of the permutations of an array

function permutations(array) {

}
