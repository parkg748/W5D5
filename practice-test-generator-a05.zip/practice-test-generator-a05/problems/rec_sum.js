// Write a recursive method that returns the sum of all elements in an array

function recSum(nums) {

}
