Array.prototype.rotate = function (num) {

}
