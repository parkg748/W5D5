// returns all subsets of an array

function subsets(array) {
  if (array.length === 0) return [[]];

  let last = array[array.length - 1];

  let subs = subsets(array.slice(0, array.length - 1));

  let sets = subs.map((sub) => sub.concat([last]));

  return subs.concat(sets);
}
