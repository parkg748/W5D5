// return b^n recursively. Your solution should accept negative values
// for n

function exponent(b, n) {

}
